$(document).ready(function() {
    new DataTable('#example', {
        layout: {
            topStart: null,
            topEnd: null,
            bottomStart:null,
            bottomEnd: null
        }
    });
});

$(document).ready(function() {
    new DataTable('#exampleFilm', {
        layout: {
            topStart: null,
            topEnd: null,
            bottomStart:null,
            bottomEnd: null
        }
    });
});

$(document).ready(function() {
    new DataTable('#exampleSeries', {
        layout: {
            topStart: null,
            topEnd: null,
            bottomStart: null,
            bottomEnd: null
        }
    });
});